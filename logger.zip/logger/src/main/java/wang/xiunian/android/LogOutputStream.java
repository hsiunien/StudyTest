package wang.xiunian.android;

import java.io.BufferedOutputStream;
import java.io.FilterOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Arrays;

/**
 * Created by wangxiunian on 2016/10/20.
 */

public class LogOutputStream extends FilterOutputStream {
    private static int sMaxLength = 1024;
    private CacheData mCacheData;

    public LogOutputStream(OutputStream out) {
        super(new BufferedOutputStream(out));
        mCacheData = new CacheData(sMaxLength);
    }

    @Override
    public void write(byte[] b) throws IOException {

        super.write(b);
    }

    class CacheData {

        private byte[] mBuffer;
        private byte[] mOverFlow;
        private int mPos;

        CacheData(int maxSize) {
            mBuffer = new byte[maxSize];
            mPos = -1;
        }

        public boolean isOverflow(byte[] data) {
            int out = mPos + data.length - mBuffer.length + 1;
            int len = out < 0 ? data.length : data.length - out;
            System.arraycopy(data, 0, mBuffer, mPos + 1, len);
            mPos = mPos + len;
            boolean isOverflow = out >= 0;
            if (isOverflow) {
                mOverFlow = new byte[mPos + 1];
                System.arraycopy(mBuffer, 0, mOverFlow, 0, mOverFlow.length);
                reset();
                byte[] overData = new byte[out];
                System.arraycopy(mBuffer, 0, mOverFlow, 0, mOverFlow.length);
            }
            return isOverflow;
        }

        public byte[] getCachedBuff() {
            return mOverFlow;
        }

        public void reset() {
            mPos = -1;
            Arrays.fill(mBuffer, (byte) 0);
        }
    }
}
